# 🤖 Iron Siege

A mobile-first 3D robot shooter that runs in the browser (Three.js, single HTML file).

**Features:** landscape touch controls, 3 maps, waves + bosses, coins & weapon shop, fighter-jet airstrikes, auto turrets, supply drops, offline play.

## Play
Enable GitHub Pages: *Settings → Pages → Deploy from branch → main / (root)*, then open `https://<user>.github.io/<repo>/` on your phone and use *Add to Home Screen*.

> Online rooms need the Claude artifact runtime and are hidden when hosted on GitHub Pages. A real multiplayer backend (e.g. WebSocket server) would be needed for that.

## License
MIT
